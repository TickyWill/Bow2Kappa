__version__ = "0.0.0"
__author__ = 'F. Bertin, A. Chabli'
__license__ = "MIT"

from .BatchPlot import *
from .BatchStat import *


